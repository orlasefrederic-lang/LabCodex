# NetStrazh 1.1.12 — независимая проверка изменений вне DNS

Дата: 29 октября 2026. Сравнение с исходниками 1.1.10 из предыдущего обзора. Это статическая проверка: сборку, ADB и нагрузочные испытания выполняет основной проверяющий отдельно. Исходники приложения не изменялись. Модель использования: личный телефон, доверенные ручные обновления, без намеренно вредоносных установленных приложений.

Новые ограничители ресурсов и повторное определение UID действительно добавлены. Однако прежнюю проблему неизвестного UID нельзя считать исправленной, а ресурсную защиту — полной. Нового подтверждённого критического дефекта в рассмотренных изменениях не выявлено; ниже перечислены конкретные остаточные проблемы и пределы подтверждения.

## Неизвестный UID: улучшение атрибуции, прежнее разрешающее поведение сохраняется

**Статус: частичное улучшение; основная проблема остаётся.** При ошибке Android API сервис всё ещё возвращает `-1` ([FirewallService.kt:249][owner]). `flagsForUid(uid < 0)` возвращает `0`, а `isBlocked()` при нулевых флагах разрешает соединение ([Rules.kt:117][rules]). Правила конкретного приложения для доменов также недоступны при неизвестном UID; глобальные доменные правила продолжают проверяться ([Rules.kt:100][host-rules]).

Изменение TCP: перед созданием записи выполняется исходная попытка и до трёх повторов определения владельца с паузами по 20 мс ([Engine.kt:322][tcp-uid]). После всех неудач создаётся `Conn(uid=-1)` и применяется прежняя разрешающая политика. Это ограниченная повторная атрибуция, но не отказ при окончательно неизвестном владельце.

Изменение UDP: первая попытка остаётся в `create()`, а для обычного UDP с неизвестным владельцем выставляется `uidLookups=1` ([UdpRelay.kt:178][udp-create]). Последующие пакеты после первых 100 мс могут вызвать до трёх дополнительных проверок ([UdpRelay.kt:93][udp-uid]). Если владелец обнаружен, сессия закрывается и создаётся заново. Первый пакет и пакеты до успешной повторной атрибуции уже проходят по разрешающей политике. Если четыре попытки не помогли, UID остаётся неизвестным на остаток жизни сессии. Для виртуального DNS эта новая повторная UDP-атрибуция не включена.

Практическое следствие: обычная ошибка или гонка определения UID всё ещё может пропустить трафик приложения, для которого пользователь задал запрет. Это не утверждение, что каждый неизвестный UID соответствует запрещённому приложению, и не экспериментальное воспроизведение гонки Android в 1.1.12. Рекомендуется явная политика для окончательно неизвестного владельца; разрешение системного DNS следует определять отдельно.

## Ограничители TCP/UDP: существенное улучшение с оставшимися пробелами

**Статус: частично исправлено.**

* Новые принятые TCP-соединения ограничиваются счётчиком `relays` и значением `MAX_TCP_RELAYS=2000`; при превышении соединение сбрасывается, NAT отмечается закрытым ([Engine.kt:293][tcp-cap], [Engine.kt:641][limits]). Проверка и инкремент раздельные; при одновременно работающих IPv4/IPv6 accept-потоках возможен небольшой выход за порог. Это не существенный обход лимита.
* Пул TCP остаётся `newCachedThreadPool` с запросом стека 256 КиБ на поток ([Engine.kt:97][tcp-pool]). Обычное активное TCP-соединение использует отдельный relay-поток и отдельную задачу обратного направления ([Engine.kt:392][tcp-pumps]). Таким образом, лимит в 2000 соединений всё ещё допускает приблизительно 4000 рабочих потоков; для обычного TCP номинальный суммарный размер запрошенных стеков может составить около 1 ГиБ, без прочих структур. Реальная память и порог отказа зависят от Android/ART; исчерпание ресурсов здесь не воспроизводилось. Нельзя повторять прежнюю формулировку «число активных relay совсем не ограничено», но нельзя и утверждать, что этот лимит подтверждён как безопасный для телефона.
* Для обычного TCP добавлено закрытие после двух часов без переданных данных; `lastAt` обновляется обоими направлениями ([Live.kt:39][last-at], [Engine.kt:623][tcp-idle]).
* **TCP-соединения к виртуальному DNS не попадают под новый тайм-аут простоя.** Они помечаются `proto="DNS"` ([Engine.kt:334][tcp-dns-kind]), а housekeeping проверяет только `proto == "TCP"`. Чтение следующего DNS-кадра блокирующее и без клиентского тайм-аута ([Engine.kt:417][tcp-dns-read], [Engine.kt:487][read-exactly]). NAT также не удаляет принятые незакрытые записи ([Nat.kt:74][nat-sweep]). Пока клиент не закрывает сокет или VPN не перезапускается, такая сессия может удерживать поток, сокет и один из общих TCP-слотов. Это проверенный по коду пробел новой очистки, а не воспроизведённое заполнение всех слотов.
* UDP теперь ограничен 4096 сессиями, сверх этого новые потоки молча отбрасываются ([UdpRelay.kt:175][udp-cap], [UdpRelay.kt:469][udp-limits]). Сохраняются ограниченный setup-пул (64 потока, очередь 1024) и тайм-ауты простоя. Предыдущее утверждение об отсутствии общего лимита UDP-сессий для 1.1.12 больше неверно.

Рекомендуется выбирать лимит по реальному бюджету потоков/памяти устройства, добавить квоты или справедливое распределение между UID и охватить тайм-аутами все TCP-сессии, включая DNS. При возможности использовать ограниченное число потоков и неблокирующий ввод-вывод.

## Журнал: ограничено число сохраняемых строк после очистки

**Статус: улучшено, строгого лимита размера файла/очереди нет.** Новый SQL удаляет строки сверх последних 300000 при `pruneAsync()` ([Db.kt:110][db-prune], [Db.kt:137][db-max]). Запрос с `OFFSET 300000` оставляет ровно до 300000 последних ID после успешного выполнения.

Очистка запускается при старте движка и далее раз в шесть часов ([FirewallService.kt:39][prune-task], [FirewallService.kt:124][prune-start], [FirewallService.kt:326][prune-period]). Между циклами строк может быть больше. Очередь `ConcurrentLinkedQueue` по-прежнему не ограничена ([Db.kt:65][db-queue]); SQL DELETE сам по себе не устанавливает физический потолок размера SQLite-файла. Это корректное ограничение сохранённых строк на момент очистки, но комментарий «около 50 MB» не следует трактовать как измеренную или жёсткую гарантию. Длительная очистка и рост файла экспериментально не проверялись.

## Прочие сохранённые исправления

`ProxyTester.kt`, `Rules.kt`, `Nat.kt`, Manifest и Gradle-конфигурация не изменились по сравнению с 1.1.10. Прежние исправления проверки TLS hostname и Android API 29 не отменены рассматриваемым diff. Контейнер подписи по-прежнему поставляется в проекте; его содержимое и значения параметров не читались и не приводятся. В согласованной модели ручных доверенных обновлений это условное усиление, а не главный практический риск.

## Restart: исправление прежнего сбоя захвата по коду не установлено

Основной путь `startEngine` / `establishTun` / `stopEngine` / `shutdown` / `restartEngine` и `NetMonitor` не изменён по сравнению с 1.1.10 ([FirewallService.kt:98][start-engine]). Изменение политики исключений прокси само по себе не объясняет и не устраняет прежний сбой прямого режима без исключений. Результат старого instrumentation-процесса нельзя переносить на обычные приложения или объявлять исправленным без текущего испытания.

Новый `t20_powerSwitchOffAndOn` действительно улучшен: после включения проверяет свежую запись TCP для своего UID и затем для shell UID 2000 ([E2eTest.kt:467][restart-test]). Но при провале первой проверки выполнение завершается, поэтому проверка shell не запускается. Для выяснения применимости прежнего сбоя нужен отдельный тест другого UID, который выполняется независимо от результата собственного процесса. Shell — другой процесс/UID, но всё же не обычное установленное приложение; независимый UDP после цикла новым тестом не проверяется.

## Прокси: автоматические исключения сужены, идентичность не закреплена

**Автоматическое исключение произвольного приложения-владельца порта исправлено в конкретной прежней форме.** `onProxyApp()` теперь допускает автоматическое исключение только для пакета из `ProxyApps.known`; неизвестный пакет записывается как предложение ([FirewallService.kt:232][proxy-exclusion]). Применить такое предложение можно отдельным действием в интерфейсе ([SettingsActivity.kt:360][proxy-confirm]).

**Проверки ожидаемой идентичности сервера всё ещё нет.** `learnProxyUid()` принимает фактического владельца сокета, не сравнивая его с `cfg.appPkg`; этот UID получает прямой маршрут для предотвращения петли ([Upstream.kt:181][proxy-owner], [Upstream.kt:123][proxy-route]). Подключённому endpoint по-прежнему передаются SOCKS/HTTP-запросы и, если настроены, данные аутентификации ([Upstream.kt:262][proxy-handshake]). Один известный пакет может автоматически заменить другой настроенный известный пакет. При этом прямой маршрут обнаруженного UID внутри VPN не равнозначен обходу правил самого firewall: обычные правила UID проверяются раньше в Engine/UdpRelay. В принятой модели доверенных приложений это условное усиление, без продемонстрированной атаки.

Определение владельца медленно принимающего прокси изменено: сначала запрашивается UID слушающего сокета с несовпадающим peer, затем UID соединения; результат `0` из второй проверки не принимается ([Upstream.kt:185][proxy-listener]). Это адресует ошибочную атрибуцию accept queue как root. Новый тест использует медленный прокси в том же процессе и ожидает `UID_NONE` ([E2eTest.kt:426][slow-proxy-test]); он не доказывает правильность UID отдельного приложения на всех Android.

При включённом Android «Блокировать соединения без VPN» пакет прокси теперь сохраняется внутри VPN и не добавляется автоматически в исключения ([FirewallService.kt:214][lockdown]). Это полезное изменение политики; сценарий lockdown и его переключение во время работающего VPN статически подтвердить нельзя.

## Новый короткий тайм-аут локального прокси: вопрос корректности диагностики

Бюджет SOCKS/HTTP handshake для loopback уменьшен с 20 до 6 секунд ([Upstream.kt:401][handshake-timeout], [Upstream.kt:458][handshake-limit]). Таймер оборачивает не только локальное приветствие/аутентификацию, но и ожидание полного CONNECT-ответа ([Upstream.kt:265][proxy-handshake]). Прокси вправе быстро ответить на приветствие, затем ждать установления связи с удалённым назначением перед завершением CONNECT. Поэтому медленное удалённое соединение может получить преждевременный отказ и сообщение «система усыпила или оно зависло» с отметкой прокси как недоступного ([Upstream.kt:405][silent-proxy]). Предположение комментария, что любой локальный прокси отвечает до dial, не является общим свойством SOCKS/HTTP.

Это проверяемый целевым тестом новый риск корректности и диагностики, а не воспроизведённый отказ реального v2rayNG в текущем стенде. Для проверки нужен локальный корректный SOCKS/HTTP-ответчик, который немедленно завершает приветствие, а успешный CONNECT выдаёт через 7–8 секунд; отдельно следует проверить состояние остальных соединений и настроенное поведение fallback.

Подробная независимая проверка restart/proxy: [restart-proxy-audit.md](/workspace/netstrazh-v1.1.12-review/restart-proxy-audit.md). Нагрузочное исчерпание ресурсов, реальный сбой атрибуции Android, долгий цикл очистки журнала и lockdown в этой ветке проверки не запускались. Никакие старые успешные результаты не засчитываются как результаты 1.1.12.

[owner]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:249
[rules]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/data/Rules.kt:117
[host-rules]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/data/Rules.kt:100
[tcp-uid]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:322
[udp-create]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/UdpRelay.kt:178
[udp-uid]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/UdpRelay.kt:93
[tcp-cap]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:293
[limits]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:641
[tcp-pool]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:97
[tcp-pumps]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:392
[last-at]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Live.kt:39
[tcp-idle]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:623
[tcp-dns-kind]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:334
[tcp-dns-read]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:417
[read-exactly]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Engine.kt:487
[nat-sweep]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Nat.kt:74
[udp-cap]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/UdpRelay.kt:175
[udp-limits]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/UdpRelay.kt:469
[db-prune]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/data/Db.kt:110
[db-max]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/data/Db.kt:137
[prune-task]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:39
[prune-start]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:124
[prune-period]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:326
[db-queue]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/data/Db.kt:65
[start-engine]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:98
[restart-test]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/androidTest/java/lab/netstrazh/E2eTest.kt:467
[proxy-exclusion]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:232
[proxy-confirm]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/ui/SettingsActivity.kt:360
[proxy-owner]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:181
[proxy-route]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:123
[proxy-handshake]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:265
[proxy-listener]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:185
[slow-proxy-test]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/androidTest/java/lab/netstrazh/E2eTest.kt:426
[lockdown]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/FirewallService.kt:214
[handshake-timeout]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:401
[handshake-limit]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:458
[silent-proxy]: /workspace/netstrazh-v1.1.12-review/sources/Lab-claude-confident-cray-n5kkx8/NetStrazh/app/src/main/java/lab/netstrazh/vpn/Upstream.kt:405
